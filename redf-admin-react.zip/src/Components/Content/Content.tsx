import React from 'react'
import Filters from '../Filters/Filters.tsx'
import ServicesSettings from '../ServicesSettings/ServicesSettings.tsx'

function Content() {
    return (
        <div className="content">
            <Filters />
            <ServicesSettings />
        </div>
    )
}

export default Content